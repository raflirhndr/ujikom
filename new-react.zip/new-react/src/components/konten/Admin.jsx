import React, { useState, useEffect } from "react";
import axios from "axios";
import "../css/foods.css";
import Swal from "sweetalert2";
import { useNavigate } from "react-router";

const FormatDescription = (description) => {
  return description.substring(0, 100) + "...";
};

function Admin() {
  const [data, setData] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    axios
      .get("http://localhost:3001/categories")
      .then((response) => {
        setData(response.data);
      })
      .catch((error) => {
        console.log(error);
      });
  }, []);

  const handleEdit = (id) => {
    navigate(`/Edit/${id}`);
  };

  const handleDelete = (id) => {
    axios
      .delete(`http://localhost:3001/categories/${id}`)
      .then(() => {
        setData(data.filter((item) => item.id !== id));
        Swal.fire({
          icon: "success",
          title: "Deleted!",
          text: "The category has been deleted.",
        });
      })
      .catch((error) => {
        console.log(error);
        Swal.fire({
          icon: "error",
          title: "Oops...",
          text: "Something went wrong!",
        });
      });
  };

  const filteredData = data.filter((item) =>
    item.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <>
      <div className="search">
        <input
          type="text"
          placeholder=" Search by Name..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
      </div>
      <div className="Foods">
        {filteredData.map(
          (
            item // Changed data to filteredData here
          ) => (
            <div key={item.id} className="card_foods">
              <img src={item.image} alt={item.name} />
              <section>
                <h5>
                  <strong> {item.name}</strong>
                </h5>
                <p>{FormatDescription(item.description)}</p>
                <button onClick={() => handleEdit(item.id)}>Edit</button>
                <button onClick={() => handleDelete(item.id)}>Delete</button>
              </section>
            </div>
          )
        )}
      </div>
    </>
  );
}

export default Admin;
