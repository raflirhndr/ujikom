import React, { useEffect, useState } from "react";
import "../css/contact.css";
import { useParams, useNavigate } from "react-router";
import axios from "axios";
import Swal from "sweetalert2";

function Edit() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [category, setCategory] = useState({});

  useEffect(() => {
    axios
      .get("http://localhost:3001/categories/" + id)
      .then((res) => setCategory(res.data))
      .catch((err) => console.log(err));
  }, [id]);

  const handleFormSubmit = (e) => {
    e.preventDefault();
    axios
      .put(`http://localhost:3001/categories/${id}`, category)
      .then((res) => {
        Swal.fire({
          icon: "success",
          title: "Success",
          text: "Category updated successfully",
        }).then(() => {
          navigate("/Foods/admin");
        });
      })
      .catch((err) => {
        Swal.fire({
          icon: "error",
          title: "Error",
          text: "Error updating category",
          footer: err.message,
        });
      });
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setCategory((prevCategory) => ({
      ...prevCategory,
      [name]: value,
    }));
  };

  return (
    <div className="Contact">
      <form onSubmit={handleFormSubmit}>
        <div className="form-group">
          <label htmlFor="image">Image :</label>
          <input
            type="text"
            id="image"
            name="image"
            value={category.image || ""}
            onChange={handleInputChange}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="name">Name :</label>
          <input
            type="text"
            id="name"
            name="name"
            value={category.name || ""}
            onChange={handleInputChange}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="description">Description :</label>
          <textarea
            id="description"
            name="description"
            rows="4"
            value={category.description || ""}
            onChange={handleInputChange}
            required
          ></textarea>
        </div>
        <button type="submit">Submit</button>
      </form>
    </div>
  );
}

export default Edit;
