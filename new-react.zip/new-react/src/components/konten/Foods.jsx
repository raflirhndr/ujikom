import React, { useState, useEffect } from "react";
import axios from "axios";
import "../css/foods.css";
import Swal from "sweetalert2";

const FormatDescription = (description) => {
  return description.substring(0, 100) + "...";
};

function Foods(props) {
  const [data, setData] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");

  const buy = () => {
    Swal.fire({
      title: " Thanks For Buying!",
      text: " Your Food is Being Cooked !",
      icon: "success",
    });
  };

  useEffect(() => {
    axios
      .get("http://localhost:3001/categories")
      .then((response) => {
        setData(response.data);
      })
      .catch((error) => {
        console.log(error);
      });
  }, []);

  // Filter data based on searchQuery
  const filteredData = data.filter((item) =>
    item.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <>
      <div className="search">
        <input
          type="text"
          placeholder=" Search by Name..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
      </div>
      <div className="Foods">
        {filteredData.map((item) => (
          <div key={item.id} className="card_foods">
            <img src={item.image} alt={item.name} />
            <section>
              <h5>
                <strong> {item.name}</strong>
              </h5>
              <p>{FormatDescription(item.description)}</p>
              <button onClick={buy}>Buy</button>
            </section>
          </div>
        ))}
      </div>
    </>
  );
}

export default Foods;
