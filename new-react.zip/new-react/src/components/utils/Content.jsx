import React from "react";
import "../css/content.css";
import Image1 from "../assets/image1.jpg";
import Image2 from "../assets/Image2.jpg";
import Image3 from "../assets/Image3.jpg";
import Image4 from "../assets/Image4.jpg";
import Image5 from "../assets/Image5.jpg";
import Image6 from "../assets/image6.jpg";

function Content() {
  return (
    <div class="content">
      <div className="card">
        <img src={Image1} class="section media" />
        <img src={Image2} class="section media" />
        <img src={Image3} class="section media" />
        <img src={Image4} class="section media" />
        <img src={Image5} class="section media" />
        <img src={Image6} class="section media" />
      </div>
      <div className="helper">
        <h3>Judul</h3> <br />
        <p>
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Quisquam,
          ducimus omnis non accusantium totam hic quod sapiente quo rem ea vel
          fuga expedita cum error veniam debitis voluptate doloribus alias!
        </p>
      </div>
    </div>
  );
}

export default Content;
